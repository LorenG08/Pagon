package com.weatherapp

import WeatherData
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private val apiKey = "30ca577aae6f2ade25703e6db0b7fbef"

    private lateinit var temperatureText: TextView
    private lateinit var descriptionText: TextView
    private lateinit var longDescriptionText: TextView
    private lateinit var weatherIcon: ImageView
    private lateinit var progressBar: ProgressBar
    private lateinit var refreshButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializeViews()
        setupRefreshButton()
        loadWeatherData()
    }

    private fun initializeViews() {
        temperatureText = findViewById(R.id.temperatureText)
        descriptionText = findViewById(R.id.descriptionText)
        longDescriptionText = findViewById(R.id.longDescriptionText)
        weatherIcon = findViewById(R.id.weatherIcon)
        progressBar = findViewById(R.id.progressBar)
        refreshButton = findViewById(R.id.refreshButton)
    }

    private fun setupRefreshButton() {
        refreshButton.setOnClickListener {
            loadWeatherData()
        }
    }

    private fun loadWeatherData() {
        // Use lifecycleScope for safer coroutine management
        lifecycleScope.launch {
            showLoading(true)
            try {
                Log.d("WeatherApp", "Fetching weather data...") // <-- Add logging
                val weatherData = fetchWeatherData()
                updateUI(weatherData)
                Log.d("WeatherApp", "Successfully fetched and updated UI.") // <-- Add logging
            } catch (e: Exception) {
                // CRITICAL: Log the actual error to see what's failing
                Log.e("WeatherApp", "Failed to load weather data", e)
                showError("Failed to load weather data. Check logs for details.")
            } finally {
                showLoading(false)
            }
        }
    }

    private suspend fun fetchWeatherData(): WeatherData {
        return withContext(Dispatchers.IO) {
            val response = RetrofitInstance.weatherApiService.getCurrentWeather(
                city = "New York",
                apiKey = apiKey
            )

            // Transform API response to local model
            val weather = response.weather.first()
            val iconUrl = "https://openweathermap.org/img/wn/${weather.icon}@4x.png"

            WeatherData(
                location = response.name,
                temperature = "${response.main.temp.toInt()}°C",
                shortDescription = weather.main,
                longDescription = weather.description.replaceFirstChar { it.uppercase() },
                iconUrl = iconUrl
            )
        }
    }

    private fun updateUI(weatherData: WeatherData) {
        temperatureText.text = weatherData.temperature
        descriptionText.text = weatherData.shortDescription
        longDescriptionText.text = weatherData.longDescription

        // Load weather icon using Glide
        Glide.with(this)
            .load(weatherData.iconUrl)
            .into(weatherIcon)
    }

    private fun showLoading(show: Boolean) {
        progressBar.visibility = if (show) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()

        // Reset UI to default state
        temperatureText.text = "--°C"
        descriptionText.text = "--"
        longDescriptionText.text = "--"
    }
}
